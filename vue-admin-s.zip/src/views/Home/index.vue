<template>
  <div class="Home-container">
    首页
  </div>
</template>

<script>
export default {
  name: 'Home',
  data() {
    return {
    }
  },
  created() {
  },
  computed: {
  },
  methods: {
  },
}
</script>

<style lang="less" scoped>
</style>
